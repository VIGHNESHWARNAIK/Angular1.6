angular.module('myapp')
    .component('about', {
        templateUrl: 'components/about/about.component.html'
    });