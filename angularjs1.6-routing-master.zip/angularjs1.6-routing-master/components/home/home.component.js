angular.module('myapp')
    .component('home', {
        templateUrl: 'components/home/home.component.html'
    });