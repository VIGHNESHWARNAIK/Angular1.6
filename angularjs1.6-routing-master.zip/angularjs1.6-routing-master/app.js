angular.module('myapp', ['ui.router']);

angular.module('myapp')
    .component('app', {
        templateUrl: 'app.component.html',
        controller: function(){
        }
    });
